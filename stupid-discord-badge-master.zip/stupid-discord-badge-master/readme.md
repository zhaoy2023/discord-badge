# I hate Discord so I made this

### How to use
- Create an application at the [Developer panel](https://discord.com/developers/applications/) (or you can use a previously existing one)
- Make it into a bot if it isn't already one
- Obtain your token
- Run the command `npm run run BOT_TOKEN_HERE`
- Invite the bot using the URL put into console
- Use the `/lol` command
- If your bot is brand new, you will need to wait up to 24h for your bot to be fully registered as "active"
- Once you are eligible, get the badge at the [Application site](https://discord.com/developers/active-developer)

### Example
`npm run run V2h5IGRpZCB5b3UgYWN0dWFsbHkgZGVjb2RlIGl0Pw.GIxRdU._UxMrJsWYKLAROyis_Kkv7XsXk-7Hjvuc7nIXg`


### Extra note
Silly cat :3
